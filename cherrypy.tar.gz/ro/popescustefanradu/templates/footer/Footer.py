from ro.popescustefanradu.templates.Base import Renderable


class FooterView(Renderable):
    pass
